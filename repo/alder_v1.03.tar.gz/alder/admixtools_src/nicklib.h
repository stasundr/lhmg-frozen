#ifdef __cplusplus
extern "C" {
#endif
#include <vsubs.h>
#include <strsubs.h>
#include <sortit.h>
#include <statsubs.h>
#include <linsubs.h>  
#include <ranmath.h>
#include <xsearch.h>

#ifdef __cplusplus
}
#endif
