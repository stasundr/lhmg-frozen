#ifdef __cplusplus
extern "C" {
#endif

void sortit(double *a, int *ind, int len)  ;
int compit (int *a1, int *a2) ; 
void isortit(int *a, int *ind, int len)  ;
int icompit (int *a1, int *a2) ; 
void invperm(int *a, int *b, int n) ; 
int ipcompit (int *a1, int *a2)  ;
int compiarr(int *a, int *b, int len)  ;
void ipsortit(int **a, int *ind, int len, int rlen)  ;
void ipsortitp(int **a, int *ind, int len, int rlen, int *pp)  ;
void setorder (int *pp, int rlen) ;

#ifdef __cplusplus
}
#endif
