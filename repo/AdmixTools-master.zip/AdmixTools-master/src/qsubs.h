#ifdef __cplusplus
extern "C" {
#endif
#include "admutils.h" 
void setccr(double aa, double bb, double *qrho, double *qtr, int numrisks)  ;
void setqscores(Indiv *indx, double *gg, double *qsc)  ;
void calcbmv(double aa, double bb, double *mean, double *var)  ;
void setqcox(double *qcc, double aa, double bb, 
  double qrho, double qtrisk) ;
void setqco(double *qc, double aa, double bb)  ;
void setqscores(Indiv *indx, double *gg, double *qsc)  ;
void freecc() ; 
double genqval(double *qcc, double theta, double mu, int a)  ;
double lnordens(double xval, double sig)  ;
double qqlike(double qval, double *cc, double theta, double mu, int a) ;
void probit(double *xout, double *xin, int n) ;
void doprobit(Indiv **indm, int numind) ;
double qqltot(Indiv **indivmarkers, int numindivs, double *ccr, double qmu) ;

#ifdef __cplusplus
}
#endif
