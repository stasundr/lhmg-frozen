#ifdef __cplusplus
extern "C" {
#endif
int iscanon(int a, int b, int c, int d) ;
void getmv (int a, int b, int c, int d, double *mean, double *var, double *ff3, double *ff3var, int dimff3) ;
void bumpm(double *y, int a, int c, double val, double *ff3, int dim);
void bumpw(double *w, int a, int c, double val, int dim);

void fitclear() ; 
void fitsetup(double *ff3, double *ff3var, char **fglist, int numfg, char **elist, int numee) ;
double fitgr(double *elen, double **vmix, int *lmix, int *pnpedge, int *pnmix, int numb, double zinc) ;
void scorx(double *pscor, double *pychi)  ;
double scorppchi(double *ppwts, double *elen, double *pchi)  ;



#ifdef __cplusplus
}
#endif
